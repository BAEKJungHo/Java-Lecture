package Oepnchallenge;

public enum Position {
	부장, 차장, 과장, 대리, 사원
	// 내부적으로 인덱스를 가지는데 선언한 순서대로 0, 1, 2, 3, 4를 가진다
}
