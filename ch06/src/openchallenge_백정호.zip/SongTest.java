package openchallenge;

public class SongTest {

	public static void main(String[] args) {
		Song song = new Song("Love of My Life", "Queen", "Bohemian Rhapsody", "Freddie Mercury", 2018, 10);
		
		song.show();

	}

}
