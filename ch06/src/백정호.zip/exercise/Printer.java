package exercise;

public class Printer {

	/* 16번 문제
	void println(int number) {
		System.out.println(number);
	}
	void println(boolean result) {
		System.out.println(result);
	}
	void println(double dNumber) {
		System.out.println(dNumber);
	}
	void println(String name) {
		System.out.println(name);
	}
	*/
	
	static void println(int number) {
		System.out.println(number);
	}
	static void println(boolean result) {
		System.out.println(result);
	}
	static void println(double dNumber) {
		System.out.println(dNumber);
	}
	static void println(String name) {
		System.out.println(name);
	}
}
