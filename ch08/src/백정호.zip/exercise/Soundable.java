package exercise;

public interface Soundable {

	String sound();
}
