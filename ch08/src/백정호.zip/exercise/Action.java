package exercise;

public interface Action {

	void work();
}
