package exercise;

public interface DataAccessObject {

	public void select();
	public void insert();
	public void update();
	public void delete();
	
}
