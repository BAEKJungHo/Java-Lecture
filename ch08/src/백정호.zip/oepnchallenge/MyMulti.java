package oepnchallenge;

public interface MyMulti {
	
	public int max(int[] array);
	public int min(int[] array);
	public int sum(int[] array);
	public double avg(int[] array);

}
