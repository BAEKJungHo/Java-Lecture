package oepnchallenge;

public interface Calculator {

	public void add(int a, int b);
	public void subtract(int a, int b);
	public void multiply(int a, int b);
}
