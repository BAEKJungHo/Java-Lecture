package oepnchallenge;

public class MySortImpl implements MySort {
	
	private String[] sort = null;
	private String temp;
	
	public String[] sort(String[] strArray) {
		sort = new String[strArray.length];
		for(int i=0; i<strArray.length; i++) {
			sort[i] = strArray[i];
		}
		
        for (int i=0; i<sort.length-1; i++) {
            for (int k=0; k<sort.length-i-1; k++) {
                if ((sort[k].compareTo(sort[k+1])) > 0) {
                    temp = this.sort[k]; 
                    sort[k] = sort[k+1];
                    sort[k+1] = temp;
                }
            }
        }   
        return this.sort;
    
	}
	
	public String[] sort(String[] strArray, boolean descOrder) {
		sort = new String[strArray.length];
		for(int i=0; i<strArray.length; i++) {
			sort[i] = strArray[i];
		}
		
		if(descOrder) {
	        for (int i=0; i<sort.length-1; i++) {
	            for (int k=0; k<sort.length-i-1; k++) {
	                if ((sort[k].compareTo(sort[k+1])) < 0) {
	                    temp = this.sort[k]; 
	                    sort[k] = sort[k+1];
	                    sort[k+1] = temp;
	                }
	            }
	        }   
	        return this.sort;
		} else if(!descOrder) {
	        for (int i=0; i<strArray.length-1; i++) {
	            for (int k=0; k<strArray.length-i-1; k++) {
	                if ((strArray[k].compareTo(strArray[k+1])) > 0) {
	                    strArray[k] = this.sort[i];
	                    strArray[k] = strArray[k+1];
	                    this.sort[i] = strArray[k+1]; 
	                }
	            }
	        }   
	        return this.sort;
		}
		return null;
	}
}
