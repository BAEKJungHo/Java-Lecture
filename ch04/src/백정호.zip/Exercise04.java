package Exercise;

public class Exercise04 {
	public static void main(String[] args) {
		boolean inf = true;
		
		while(inf) {
			int num1 = (int)(Math.random()*6)+1;
			int num2 = (int)(Math.random()*6)+1;
		
			System.out.println("("+num1+","+num2 +")");
			
			if((num1+num2) != 5) {
				num1 = (int)(Math.random()*6)+1;
				num2 = (int)(Math.random()*6)+1;
			}
			else {
				inf = false;
			}
		}
		System.out.println("EXIT");

	}
}
